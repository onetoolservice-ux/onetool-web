
'use client'
import Link from 'next/link'
export default function Header(){
  return (
    <header className='bg-white shadow p-4 flex items-center justify-between'>
      <Link href='/' className='text-xl font-bold'>OT</Link>
      <nav className='flex gap-4'>
        <Link href='/ai'>AI</Link>
        <Link href='/tools'>Tools</Link>
        <Link href='/about'>About</Link>
      </nav>
    </header>
  )
}
