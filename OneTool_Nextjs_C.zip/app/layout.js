
import './globals.css'
export const metadata = { title: 'OneTool', description: 'OneTool Next.js Version' }
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
